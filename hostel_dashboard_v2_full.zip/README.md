
Hostel Dashboard v2
Features:
- Multi student login
- Admin panel
- Google sheet sync
- Auto dues calculation
- PDF export
- Hosting ready
- Payment gateway placeholder
